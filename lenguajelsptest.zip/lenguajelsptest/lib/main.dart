import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Opcional: quita la etiqueta DEBUG
      title: 'Traductor Compacto',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const AndroidCompactTranslator(),
    );
  }
}

class AndroidCompactTranslator extends StatefulWidget {
  const AndroidCompactTranslator({Key? key}) : super(key: key);

  @override
  State<AndroidCompactTranslator> createState() => _AndroidCompactTranslatorState();
}

class _AndroidCompactTranslatorState extends State<AndroidCompactTranslator> {
  final TextEditingController _textController = TextEditingController();

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Widget buildCustomButton({
    required String text,
    required VoidCallback onPressed,
    Color backgroundColor = Colors.black,
    Color textColor = Colors.white,
    EdgeInsetsGeometry padding = const EdgeInsets.symmetric(vertical: 12),
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: textColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          elevation: 0,
          padding: padding,
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            fontFamily: 'Inter',
          ),
        ),
      ),
    );
  }

  Widget buildTextInput() {
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 327),
      height: 220,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: const Color(0xFFE0E0E0),
          width: 1,
        ),
      ),
      child: TextField(
        controller: _textController,
        maxLines: null,
        expands: true,
        textAlign: TextAlign.center,
        textAlignVertical: TextAlignVertical.center,
        style: const TextStyle(
          fontSize: 14,
          color: Color(0xFF828282),
          fontFamily: 'Inter',
        ),
        decoration: const InputDecoration(
          hintText: 'Escriba aquí',
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(16),
        ),
      ),
    );
  }

  Widget buildDividerWithText(String text) {
    return Row(
      children: [
        const Expanded(child: Divider(color: Color(0xFFE6E6E6))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Color(0xFF3B3B3B),
              fontFamily: 'Inter',
            ),
          ),
        ),
        const Expanded(child: Divider(color: Color(0xFFE6E6E6))),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/icons/image_1.png',
                fit: BoxFit.cover,
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 27.0),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    SizedBox(
                      width: 170,
                      height: 170,
                      child: Image.asset(
                        'assets/icons/logo.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 40),
                    const Text(
                      'Ingrese el texto a traducir:',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                        fontFamily: 'Inter',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 48),
                    buildTextInput(),
                    const SizedBox(height: 16),
                    buildCustomButton(
                      text: 'Traducir',
                      onPressed: () {
                        print('Texto a traducir: ${_textController.text}');
                      },
                    ),
                    const SizedBox(height: 48),
                    buildDividerWithText('O pruebe estas opciones'),
                    const SizedBox(height: 48),
                    buildCustomButton(
                      text: 'Traducir audio',
                      onPressed: () {
                        print('Traducción de audio activada');
                      },
                      backgroundColor: const Color(0xFFEEEEEE),
                      textColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 70, vertical: 10),
                    ),
                    const SizedBox(height: 8),
                    buildCustomButton(
                      text: 'Traducir video',
                      onPressed: () {
                        print('Traducción de video activada');
                      },
                      backgroundColor: const Color(0xFFEEEEEE),
                      textColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 70, vertical: 10),
                    ),
                    const SizedBox(height: 48),
                    const Text(
                      'Términos y condiciones. Derechos reservados Roy Farfán',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12,
                        color: Color(0xFF4D4D4D),
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 21),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
